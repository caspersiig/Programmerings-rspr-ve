﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Casper_A_S_Sortering
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void MainSorter_Click(object sender, RoutedEventArgs e)
        {

            Sortering.SorterFiler();

        }

        private void ReverseButton_Click(object sender, RoutedEventArgs e)
        {
            RodTilIgen.SorterFiler();
        }
    }
    public class Sortering
    {
        public static void SorterFiler()
        {
            string DesktopVej = @Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + '\\';
            string TxTMappe = @"C:\Users\casper\Desktop\txtmappe\";
            string docsMappe = @"C:\Users\casper\Desktop\docsmappe\";
            string pdfMappe = @"C:\Users\casper\Desktop\pdfmappe\";



            //laver en string der har alle fulde genveje til alle filer på skrivebordet
            string[] skrivebordfiler = System.IO.Directory.GetFiles(DesktopVej);


            //laver en tom liste der hedder alletekstdoku der snart vil blive fuldt med navnede på alle txt filerne
            List<string> alletekstdoku = new List<string>();
            List<string> docsdoku = new List<string>();
            List<string> pdfdoku = new List<string>();

            //kontroller om mappen til txt filerne eksister hvis ikke så laver den den
            if (!System.IO.Directory.Exists(TxTMappe))
            {
                System.IO.Directory.CreateDirectory(TxTMappe);
            }
            if (!System.IO.Directory.Exists(docsMappe))
            {
                System.IO.Directory.CreateDirectory(docsMappe);
            }
            if (!System.IO.Directory.Exists(pdfMappe))
            {
                System.IO.Directory.CreateDirectory(pdfMappe);
            }



            //laver et for loop der kører det antal gange som skrivebordfiler arrayet er langt
            for (int i = 0; i < skrivebordfiler.Length; i++)
            {
                //fjerner den del af fil vejen som vi godt kender altså C:/Users/casper/Desktop/
                skrivebordfiler[i] = skrivebordfiler[i].Split('\\').Last();
                //tager alle de navne som vi har fra linjen over og sætter dem ind på vores liste
                if (skrivebordfiler[i].Split('.').Last() == "txt")
                    alletekstdoku.Add(skrivebordfiler[i]);
                if (skrivebordfiler[i].Split('.').Last() == "docx")
                    docsdoku.Add(skrivebordfiler[i]);
                if (skrivebordfiler[i].Split('.').Last() == "pdf")
                    pdfdoku.Add(skrivebordfiler[i]);
            }


            //her laver vi så et foreach med listen med alle .txt navnende
            foreach (string s in alletekstdoku)
            {
                //mover alle fillerne fra Desktopvej/txt til dennyemappe/txt :D
                System.IO.File.Move(DesktopVej+s, TxTMappe+s);
            }

            foreach (string s in docsdoku)
            {
                //lav det lige så den kan håndtere filer med samme navn din fucking bøøsseee!
                if (!System.IO.File.Exists(docsMappe + s))
                System.IO.File.Move(DesktopVej + s, docsMappe + s);
            }

            foreach (string s in pdfdoku)
            {
               
                System.IO.File.Move(DesktopVej + s, pdfMappe + s);
            }



        }
    }

    public class RodTilIgen
    {
        public static void SorterFiler()
        {



        }
    }
}



